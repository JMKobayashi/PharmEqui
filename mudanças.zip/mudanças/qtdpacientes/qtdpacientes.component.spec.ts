import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QtdpacientesComponent } from './qtdpacientes.component';

describe('QtdpacientesComponent', () => {
  let component: QtdpacientesComponent;
  let fixture: ComponentFixture<QtdpacientesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QtdpacientesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QtdpacientesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
