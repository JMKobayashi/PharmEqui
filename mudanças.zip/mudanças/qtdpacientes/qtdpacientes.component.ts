import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qtdpacientes',
  templateUrl: './qtdpacientes.component.html',
  styleUrls: ['./qtdpacientes.component.sass']
})
export class QtdpacientesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
